# TDDP-Repo
TDD's Plugins for RPG Maker MV

## Documentation

The website with documentation has sadly been lost due to an issue at my previous host, wherein they suddenly refused to take European credit cards and refusing to take other payment options, and subsequently deleted my account and its data. As this was a wordpress site I don't have any local backups of it, which is an error on my part, and sadly nothing I can resolve on my own. If anyone out there has PDF versions downloaded of the documentation, please feel free to share them with others. If you reach out to me I'll also add them to this repo for posterity.

In the future I'll never host documentation this way again.

## Terms of use / License

All plugins are now MIT licensed. I have updated each one with the new terms present.
